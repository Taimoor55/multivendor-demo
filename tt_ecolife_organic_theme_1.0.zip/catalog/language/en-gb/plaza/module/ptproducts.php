<?php
$_['module_product_title'] = "Products";
$_['text_empty'] = "There is no product.";
$_['text_availabe'] = "availabe:";
$_['text_sold'] = "Sold:";
$_['text_viewmore'] = "View Details";