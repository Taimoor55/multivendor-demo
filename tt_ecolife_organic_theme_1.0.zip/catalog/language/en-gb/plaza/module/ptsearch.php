<?php
// Text
$_['text_placeholder_search']       = 'Search entire store here ...';
$_['text_category']     = 'All Categories';
$_['text_empty']        = 'There are no products to list in this category.';