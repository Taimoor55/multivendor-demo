<?php
// Heading
$_['title']  = 'Login or create an account';