<?php
// Text
$_['text_heading_title']  = 'Latest Blogs';
$_['text_module_blog']  = 'Present posts in a best way to highlight interesting moments of your blog.';
$_['text_post_empty']     = 'No posts';
$_['text_blog']           = 'Blog';
$_['text_limit']          = 'Limit';
$_['text_category_title'] = 'Categories';
$_['text_latest_post']    = 'Latest Post';
$_['text_related_post']   = 'Related Post';

// Button
$_['button_show']         = 'Read More';
