<?php
// Heading
$_['heading_title']       = 'Layouts';

// Text
$_['text_success']        = 'Success: You have modified layouts!';
$_['text_list']           = 'Layout List';
$_['text_add']            = 'Add Layout';
$_['text_edit']           = 'Edit Layout';
$_['text_remove']         = 'Remove';
$_['text_route']          = 'Choose the store and routes to be used with this layout';
$_['text_module']         = 'Choose the position of the modules';
$_['text_default']        = 'Default';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';

// Custom for Plazathemes
$_['text_module_position1'] = 'Vertical Menu';
$_['text_module_position2'] = 'Hozirontal Menu';
$_['text_module_position3'] = 'Mobile Menu';
$_['text_module_position4'] = 'Module Position 4';
$_['text_module_position5'] = 'Module Position 5';
$_['text_module_position6'] = 'Module Position 6';
$_['text_module_position7'] = 'Module Position 7';
$_['text_module_position8'] = 'Module Position 8';
$_['text_module_position9'] = 'Module Position 9';
$_['text_module_position10'] = 'Module Position 10';

// Column
$_['column_name']         = 'Layout Name';
$_['column_action']       = 'Action';

// Entry
$_['entry_name']          = 'Layout Name';
$_['entry_store']         = 'Store';
$_['entry_route']         = 'Route';
$_['entry_module']        = 'Module';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify layouts!';
$_['error_name']          = 'Layout Name must be between 3 and 64 characters!';
$_['error_default']       = 'Warning: This layout cannot be deleted as it is currently assigned as the default store layout!';
$_['error_store']         = 'Warning: This layout cannot be deleted as it is currently assigned to %s stores!';
$_['error_product']       = 'Warning: This layout cannot be deleted as it is currently assigned to %s products!';
$_['error_category']      = 'Warning: This layout cannot be deleted as it is currently assigned to %s categories!';
$_['error_information']   = 'Warning: This layout cannot be deleted as it is currently assigned to %s information pages!';